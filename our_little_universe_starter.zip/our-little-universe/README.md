# Our Little Universe

A beginner-friendly, one-file interactive romantic adventure built with HTML, CSS, and JavaScript.

## Preview locally
Open `index.html` in a web browser.

## Publish with GitHub Pages
1. Create a public repository named `our-little-universe` on GitHub.
2. Upload `index.html` to the repository's root.
3. Open **Settings → Pages**.
4. Under build/deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
5. After GitHub finishes publishing, use the URL shown in the Pages section.

## Personalize it
- Replace the sample messages in the two dialog boxes with your own words.
- Replace the photo placeholder with an image tag such as:
  `<img src="our-photo.jpg" alt="A favorite photo of us" style="width:100%;border-radius:12px">`
- Upload the photo file into the same repository and use its exact filename.
- Change the astronaut emoji `🧑‍🚀` to an emoji or character you like.

Tip: Don't upload private information. A public GitHub Pages site can be viewed by anyone who has its address.
